﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Chemist
/// </summary>
public class Chemist
{
    public string id, name, address, state, city, status, emp_id, Emp_id, Emp_name;
	public Chemist()
	{
    }
}