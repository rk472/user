﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DeleteDoctor
/// </summary>
public class DeleteDoctor
{
    public String emp_id, Doctor_id, Reason;
	public DeleteDoctor()
	{
		
	}
}