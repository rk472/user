﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Doctor
/// </summary>
public class Doctor
{
    public String Id, Name, Specialization, Qualifiaction, Category, state, city, status, emp_id, doj, doa;
	public Doctor()
	{
		
	}
}