﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public String id,name,password,phone,email,dob,doj,address,photo,bloodGroup,adhar,region,hq,designation,level,gender,division,senior_id;
	public Employee()
	{
	}
}