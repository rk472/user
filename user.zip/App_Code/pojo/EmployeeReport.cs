﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EmployeeReport
/// </summary>
public class EmployeeReport
{
    public String  emp_id, date, type, reason, doc_name, meidicine, no_of_doc;
	public EmployeeReport()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}