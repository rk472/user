﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Stockist
/// </summary>
public class Stockist
{
    public string id, name, address, state, city, status, emp_id, Emp_id, Emp_name;
	public Stockist()
	{
    }
}