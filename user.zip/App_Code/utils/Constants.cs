﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Constants
/// </summary>
public class Constants
{
    public static readonly String CONNECTION_STRING = "Data Source=localhost;Port=3306;Database=test;User Id=root;Password= ";
    public Constants()
    {

    }

}